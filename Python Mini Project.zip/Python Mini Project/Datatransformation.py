import yaml
from sqlalchemy import create_engine
import pandas as pd

def load_config(config_file):
    """Load configuration from a YAML file."""
    try:
        with open(config_file, 'r') as file:
            return yaml.safe_load(file)
    except FileNotFoundError:
        raise Exception(f"Configuration file '{config_file}' not found.")
    except yaml.YAMLError as e:
        raise Exception(f"Error parsing YAML file: {e}")

def create_db_engine(config):
    """Create a SQLAlchemy engine using database configuration."""
    try:
        db = config['database']
        return create_engine(
            f"postgresql://{db['user']}:{db['password']}@{db['host']}:{db['port']}/{db['name']}"
        )
    except KeyError as e:
        raise Exception(f"Missing database configuration key: {e}")

def load_dataframes(engine):
    """Load data from the database into Pandas DataFrames."""
    try:
        customers_df = pd.read_sql("SELECT * FROM Customers", engine)
        orders_df = pd.read_sql("SELECT * FROM Orders", engine)
        restaurants_df = pd.read_sql("SELECT * FROM Restaurants", engine)
        return customers_df, orders_df, restaurants_df
    except Exception as e:
        raise Exception(f"Error loading data from database: {e}")

def check_columns(df, required_cols):
    """Ensure required columns exist in the DataFrame."""
    missing_cols = required_cols - set(df.columns)
    if missing_cols:
        raise Exception(f"Missing columns: {missing_cols}")

def process_data(customers_df, orders_df, restaurants_df):
    """Perform ETL transformations on the data."""
    # Clean column names
    customers_df.columns = customers_df.columns.str.strip()
    orders_df.columns = orders_df.columns.str.strip()
    restaurants_df.columns = restaurants_df.columns.str.strip()

    # Check for required columns
    check_columns(customers_df, {'customer_id'})
    check_columns(orders_df, {'customer_id', 'order_amount', 'restaurant_id'})
    check_columns(restaurants_df, {'restaurant_id'})

    # Calculate total spending per customer
    total_spending = orders_df.groupby('customer_id')['order_amount'].sum()

    # Filter customers with total order amount > $500
    high_spending_customers = total_spending[total_spending > 500].index
    high_spending_df = customers_df[customers_df['customer_id'].isin(high_spending_customers)]

    # Join data to get detailed order history
    customer_orders_df = pd.merge(orders_df, customers_df, on='customer_id', how='inner')
    customer_orders_restaurants_df = pd.merge(customer_orders_df, restaurants_df, on='restaurant_id', how='inner')

    # Aggregation for restaurants
    restaurant_summary = customer_orders_restaurants_df.groupby(['restaurant_id']).agg(
        total_orders=('order_amount', 'count'),
        total_revenue=('order_amount', 'sum'),
        avg_order_value=('order_amount', 'mean')
    ).reset_index()

    return customer_orders_restaurants_df, restaurant_summary, total_spending

def calculate_statistical_insights(data, config):
    """Calculate statistical insights and save to CSV."""
    customer_orders_restaurants_df, restaurant_summary, total_spending = data

    if 'order_amount' in customer_orders_restaurants_df.columns:
        avg_order_value = customer_orders_restaurants_df['order_amount'].mean()

        if 'cuisine_type' in customer_orders_restaurants_df.columns:
            cuisine_distribution = customer_orders_restaurants_df.groupby('cuisine_type')['order_amount'].count().sort_values(ascending=False)
        else:
            print("Warning: 'cuisine_type' column is missing.")
            cuisine_distribution = pd.Series()

        top_restaurants = restaurant_summary.sort_values(by='total_revenue', ascending=False).head(10)
        avg_top_restaurant_rating = top_restaurants['avg_order_value'].mean()

        if 'location' in customer_orders_restaurants_df.columns:
            city_revenue = customer_orders_restaurants_df.groupby('location')['order_amount'].sum()
            highest_revenue_city = city_revenue.idxmax()
        else:
            print("Warning: 'location' column is missing.")
            highest_revenue_city = None

        insights = {
            'Average Order Value': avg_order_value,
            'Top 10 Restaurants by Revenue': top_restaurants[['restaurant_id', 'total_revenue']],
            'Cuisine Distribution': cuisine_distribution,
            'Average Rating of Top Restaurants': avg_top_restaurant_rating,
            'Highest Revenue City': highest_revenue_city
        }

        # Save insights to CSV
        insights_df = pd.DataFrame({k: [v] for k, v in insights.items() if isinstance(v, (int, float, str))})
        insights_df.to_csv(config['files']['insights_report_csv'], index=False)

        print("\nStatistical Insights:")
        print(insights)
    else:
        print("Error: 'order_amount' column is missing in the DataFrame.")

def save_outputs(data, config):
    """Save transformed data and insights to files."""
    try:
        customer_orders_restaurants_df, restaurant_summary, total_spending = data

        # Save transformed data
        customer_orders_restaurants_df.to_sql('Customer_Order_Summary', engine, if_exists='replace', index=False)
        customer_orders_restaurants_df.to_csv(config['files']['customer_summary_csv'], index=False)

        # Display outputs
        print("Restaurant Summary:")
        print(restaurant_summary.head())

        print("\nTop 10 Customers by Total Spending:")
        print(total_spending.sort_values(ascending=False).head(10))
    except Exception as e:
        raise Exception(f"Error saving outputs: {e}")

if __name__ == "__main__":
    try:
        # Load configuration
        config = load_config("db_config.yaml")

        # Create database engine
        engine = create_db_engine(config)

        # Load data
        customers_df, orders_df, restaurants_df = load_dataframes(engine)

        # Process data
        transformed_data = process_data(customers_df, orders_df, restaurants_df)

        # Save outputs
        save_outputs(transformed_data, config)

        # Calculate and save statistical insights
        calculate_statistical_insights(transformed_data, config)

    except Exception as e:
        print(f"An error occurred: {e}")
